function output = soal_3(a,b)
output=sum(a == b);
end